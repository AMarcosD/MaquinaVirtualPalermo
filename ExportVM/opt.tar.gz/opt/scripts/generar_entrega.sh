#!/bin/bash

WORKDIR="/home/alumno/entrega_tp"
DEST="/media/sf_vm_share/entrega_tp"
MAX_SIZE=25000000  # 25 MB

mkdir -p "$WORKDIR"
mkdir -p "$DEST"
cd "$WORKDIR" || exit 1

# Función para comprimir y dividir si supera tamaño límite
comprimir_y_dividir() {
  local origen=$1
  local nombre=$2

  echo "📦 Comprimiendo $origen..."
  tar -czf "${nombre}.tar.gz" "$origen"

  local size
  size=$(stat -c%s "${nombre}.tar.gz")

  if [ "$size" -gt "$MAX_SIZE" ]; then
    echo "⚠️ ${nombre}.tar.gz excede los 25MB. Dividiendo..."
    split -b 25M "${nombre}.tar.gz" "${nombre}_part_"
    rm "${nombre}.tar.gz"
  fi
}

# Comprimir los directorios
comprimir_y_dividir /root root
comprimir_y_dividir /etc etc
comprimir_y_dividir /opt opt
comprimir_y_dividir /www_dir www_dir
comprimir_y_dividir /backup_dir backup_dir

# Comprimir contenido personalizado de /proc
echo "📦 Generando contenido personalizado para /proc..."
mkdir -p /tmp/proc_entregable

if [ -r /proc/partitions ]; then
  cp /proc/partitions /tmp/proc_entregable/partitions_original
else
  echo "No se pudo leer /proc/partitions" > /tmp/proc_entregable/partitions_original
fi

echo "Este es el archivo particion para la entrega" > /tmp/proc_entregable/particion
tar -czf proc.tar.gz -C /tmp proc_entregable

size_proc=$(stat -c%s proc.tar.gz)
if [ "$size_proc" -gt "$MAX_SIZE" ]; then
  echo "⚠️ proc.tar.gz excede los 25MB. Dividiendo..."
  split -b 25M proc.tar.gz proc_part_
  rm proc.tar.gz
fi

# Comprimir y dividir /var
echo "📦 Comprimiendo y dividiendo /var..."
tar -czf var.tar.gz /var
split -b 25M var.tar.gz var_part_
rm var.tar.gz

# Copiar todos los archivos resultantes al destino
echo "📁 Copiando archivos a $DEST..."
cp ./* "$DEST"

echo "✅ ¡Entrega generada correctamente y copiada a $DEST!"

