#!/bin/bash

# Mostrar ayuda
if [[ "$1" == "-help" ]]; then
    echo "Uso: $0 <origen> <destino>"
    echo "Ejemplo: $0 /var/log /backup_dir"
    exit 0
fi

# Verificar que se pasaron 2 argumentos
if [[ $# -ne 2 ]]; then
    echo "Error: Se requieren 2 argumentos: origen y destino."
    echo "Usá -help para más info."
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)

# Verificar que el directorio origen existe
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: El directorio origen '$ORIGEN' no existe."
    exit 2
fi

# Verificar que el directorio destino existe
if [[ ! -d "$DESTINO" ]]; then
    echo "Error: El directorio destino '$DESTINO' no existe."
    exit 3
fi

# Obtener nombre del backup según el nombre del origen
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"

# Crear el backup
tar -czf "$ARCHIVO" "$ORIGEN"

# Confirmar
echo "Backup creado: $ARCHIVO"

