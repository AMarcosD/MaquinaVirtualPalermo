#ifndef ___version_generated_h___
#define ___version_generated_h___

#define VBOX_VERSION_MAJOR 7
#define VBOX_VERSION_MINOR 1
#define VBOX_VERSION_BUILD 6
#define VBOX_VERSION_STRING_RAW "7.1.6"
#define VBOX_VERSION_STRING "7.1.6"
#define VBOX_API_VERSION_STRING "7_1"

#define VBOX_BUILD_SERVER_BUILD 1

#endif
